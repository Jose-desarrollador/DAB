package com.example.diseodeinterfazdelaappdelectordehuellas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Resultado : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)
    }
}